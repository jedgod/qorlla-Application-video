import crypto from 'node:crypto';
const normalized = x => String(x||'').replace(/[\s-]/g,'');
export async function saveSchedule(pool,x){
 const code=normalized(x.legacyCode);
 if(!/^[0-9]{10,12}$/.test(code)||!x.sourceId||!String(x.title||'').trim()||!String(x.ownerName||'').trim())throw Error('Invalid schedule');
 const c=await pool.connect();try{await c.query('BEGIN');
 const r=await c.query(`INSERT INTO qorlla_schedules(source_id,legacy_code,title,owner_name,scheduled_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(source_id) DO UPDATE SET title=EXCLUDED.title,scheduled_at=EXCLUDED.scheduled_at,version=qorlla_schedules.version+1,status='pending_sync',updated_at=now() WHERE qorlla_schedules.status NOT IN ('cancel_pending','cancelled') RETURNING *`,[x.sourceId,code,x.title,x.ownerName,x.scheduledAt||null]);
 if(!r.rowCount)throw Error('Cannot edit cancelled schedule');
 await c.query(`INSERT INTO qorlla_outbox(source_id,version,operation) VALUES($1,$2,'upsert')`,[x.sourceId,r.rows[0].version]);await c.query('COMMIT');return r.rows[0];
 }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export async function cancelScheduleLocal(pool,sourceId){const c=await pool.connect();try{await c.query('BEGIN');const r=await c.query(`UPDATE qorlla_schedules SET status='cancel_pending',version=version+1,updated_at=now() WHERE source_id=$1 AND status NOT IN ('cancel_pending','cancelled') RETURNING *`,[sourceId]);if(r.rowCount)await c.query(`INSERT INTO qorlla_outbox(source_id,version,operation) VALUES($1,$2,'cancel')`,[sourceId,r.rows[0].version]);await c.query('COMMIT');return r.rows[0]||null}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}
export function seal(secret){const key=Buffer.from(process.env.QORLLA_VAULT_KEY||'','base64');if(key.length!==32)throw Error('QORLLA_VAULT_KEY must decode to 32 bytes');const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv);const ciphertext=Buffer.concat([cipher.update(secret,'utf8'),cipher.final()]);return {ciphertext:ciphertext.toString('base64'),iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64')}}
export async function saveHostSecret(client,sourceId,secret){const s=seal(secret);await client.query(`INSERT INTO qorlla_host_vault(source_id,ciphertext,iv,tag) VALUES($1,$2,$3,$4) ON CONFLICT(source_id) DO UPDATE SET ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,updated_at=now()`,[sourceId,s.ciphertext,s.iv,s.tag])}
